/* 1. SELECTORES INPUTS*/
const proyectoInput = document.querySelector("#proyecto");
const estudianteInput = document.querySelector("#estudiante");
const telefonoInput = document.querySelector("#telefono");
const fechaInput = document.querySelector("#fecha");
const horaInput = document.querySelector("#hora");
const detallesInput = document.querySelector("#detalles");

/* 2. UI SELECTORES*/
const formulario = document.querySelector("#nueva-reunion");
const contenedorReuniones = document.querySelector("#reuniones");
/* 6. DEFINICION DE CLASES */

class Reuniones {
  // 10.2 (A) metodo Constructor
  constructor() {
    this.reuniones = [];
  }
  // 10.2 (B) metodo de agregarReunion
  agregarReunion(reunion) {
    this.reuniones = [...this.reuniones, reunion];
    console.log(this.reuniones);
  }
  // 13.5 Definicion metodo de "eliminarReunion" con metodoArray de filter
  eliminarReunion(id) {
    this.reuniones = this.reuniones.filter((reunion)=> reunion.id !== id)
  }
}

class UI {
  /* 9.  metodo para imprimir mensajes de advertencia o notificacion */
  imprimirAlerta(mensaje, tipo) {
    // 9.1 crear el div
    const divMensaje = document.createElement("div");
    // 9.2 añadimos clases "text-center", "alert", "d-block", "col-12"
    divMensaje.classList.add("text-center", "alert", "d-block", "col-12");
    // 9.3 agregar clase en base al tipo de error
    if (tipo === "error") {
      divMensaje.classList.add("alert-danger");
    } else {
      divMensaje.classList.add("alert-success");
    }
    // 9.4 mensaje de error
    divMensaje.textContent = mensaje;
    // 9.5 agregar al DOM
    document
      .querySelector("#contenido")
      .insertBefore(divMensaje, document.querySelector(".agregar-reunion"));
    // 9.6 quitar alerta despues de 5 segundos
    setTimeout(() => {
      divMensaje.remove();
    }, 5000);
  }

  // 11.1 agrego el metodo "imprimirReuniones" a la clase UI  y aplico

  imprimirReuniones({ reuniones }) {
    //  destructuring al parametro
    // 12.7 llamo metodo limpiarHTML (usar this)
    this.limpiarHTML();
    // 11.2 Accedo al arreglo de reuniones y lo itero.
    reuniones.forEach((reunion) => {
    // 11.3 aplico destructuring a cada reunion e incluyo al id
    const {proyecto, estudiante, telefono, fecha, hora, detalles, id} = reunion;
    // 11.4 creo el div para reuniones
    const divReunion = document.createElement('div');
    // 11.5 agregamos clases hoja estilos publica de padding y clase personalizada 'reunion','p-3'
    divReunion.classList.add('reunion', 'p-3')
    // 11.6 agregamos atributo id
    divReunion.dataset.id = id;
    /* 12. Scripting de los elementos html proyecto, etc (parrafos por cada input) */
    // 12.1 titulo del parrafo
    const proyectoParrafo = document.createElement('h2');
    // 12.2 agregamos clases hoja de estilos publica  "card-title", "font-weight-bolder"
    proyectoParrafo.classList.add("card-title", "font-weight-bolder");
    // 12.3 agregamos texto de titulo al parrafo
    proyectoParrafo.textContent = proyecto;
    // 12.8 agregamos estudianteParrafo y el resto parrafos al innerHTML y
    // al divReunion por el resto de campos y se repite el ciclo
    //  <span class="font-weight-bolder">Estudiante: </span> ${estudiante}
    const estudianteParrafo = document.createElement('p');
    estudianteParrafo.innerHTML = `<span class="font-weight-bolder">Estudiante: </span> ${estudiante}`
    const telefonoParrafo = document.createElement('p');
    telefonoParrafo.innerHTML = `<span class="font-weight-bolder">Telefono: </span> ${telefono}`
    const fechaParrafo = document.createElement('p');
    fechaParrafo.innerHTML = `<span class="font-weight-bolder">Fecha: </span> ${fecha}`
    const horaParrafo = document.createElement('p');
    horaParrafo.innerHTML = `<span class="font-weight-bolder">Hora: </span> ${hora}`
    const detallesParrafo = document.createElement('p');
    detallesParrafo.innerHTML = `<span class="font-weight-bolder">Detalles: </span> ${detalles}`
    /* 13  ELIMINAR REUNIONES */
    // 13.1 crear boton para eliminar reuniones, con sus clases de estilo e innerHTML Y svg
    // "btn", "btn-danger", "mr-2"
    const btnEliminar = document.createElement('button');
    btnEliminar.classList.add("btn", "btn-danger", "mr-2");
    btnEliminar.innerHTML = `Eliminar <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>`;
    // 13.3 Seleccionamos el btnEliminar - Mouseevento onclick
    // para eliminar una reunion llamando a la funcion respectiva eliminarReunion(id)
    // pasamos el id de reunion para identificar cual borrar
    btnEliminar.onclick = ()=> eliminarReunion(id);
    // 12.4 agregamos el parrafo (PROYECTO Y DEMAS) al divReunion creado
    divReunion.appendChild(proyectoParrafo);
    divReunion.appendChild(estudianteParrafo);
    divReunion.appendChild(telefonoParrafo);
    divReunion.appendChild(fechaParrafo);
    divReunion.appendChild(horaParrafo);
    divReunion.appendChild(detallesParrafo);
    // 13.2 agregamos boton eliminar al divReunion
    divReunion.appendChild(btnEliminar);
    // 12.5 agregar el divReunion al contenedor de reuniones
    // (agregar reuniones al html)
    contenedorReuniones.appendChild(divReunion);
    });
  }
  // 12.6 defino el metodo "limpiarHTML" en la clase UI
  limpiarHTML(){
    while (contenedorReuniones.firstChild) {
      contenedorReuniones.removeChild(contenedorReuniones.firstChild);
    } 
  }
  
}

/* 7.  INSTANCIAS DE CLASE (objetos POO)*/
const ui = new UI();
const administrarReuniones = new Reuniones();

/* 3.  REGISTRO DE EVENTOS - EVENTLISTENERS */
proyectoInput.addEventListener("input", datosReunion);
estudianteInput.addEventListener("input", datosReunion);
telefonoInput.addEventListener("input", datosReunion);
fechaInput.addEventListener("input", datosReunion);
horaInput.addEventListener("input", datosReunion);
detallesInput.addEventListener("input", datosReunion);

formulario.addEventListener("submit", nuevaReunion);

/* 5. objeto para tratamiento de reuniones */
const objetoReuniones = {
  proyecto: "",
  estudiante: "",
  telefono: "",
  fecha: "",
  hora: "",
  detalles: "",
};

/* 4. funciones */
/* agrega datos al objeto reuniones */

function datosReunion(e) {
  objetoReuniones[e.target.name] = e.target.value;
  /*  console.log(objetoReuniones); */
}

/* 8. Funcion que valida y agrega nueva reunion al objetoReuniones - (submit Formulario) */
function nuevaReunion(e) {
  // 8.1 prevent
  e.preventDefault();
  // 8.2 Extrae la informacion del objeto de reunion (destructuring)
  const { proyecto, estudiante, telefono, fecha, hora, detalles } =
    objetoReuniones;
  // 8.3 Valida que no existan Inputs vacios
  if (
    proyecto === "" ||
    estudiante === "" ||
    telefono === "" ||
    fecha === "" ||
    hora === "" ||
    detalles === ""
  ) {
    // 8.4 llamo al metodo "imprimirAlerta" de la instancia ui de la clase UI (crear metodo)
    ui.imprimirAlerta("Todos los campos deben estar llenos", "error");
    return;
  }

  /* 10. CREAR UNA NUEVA REUNION */
  // 10.1 creo un id unico para la reunion.
  objetoReuniones.id = Date.now();
  // 10.2 creo y defino el constructor y el metodo "agregarReunion" en la clase Reuniones

  // 10.3 llamo al metodo "agregarReunion" con el objeto instanciado  de la clase Reuniones
  // Y LE PASO <UNA COPIA> del objeto y (EXTRAIGO DESDE PARENTESIS DE PARAMETROS)
  administrarReuniones.agregarReunion({ ...objetoReuniones });
  // 10.4 Reiniciar el formulario una vez se cree la nueva reunión
  formulario.reset();
  // 10.6 llamado funcion para limpiar objeto
  reiniciarObjeto();
  /* 11. MOSTRAR EL HTML DE LAS REUNIONES */
  // llamo al metodo "imprimirReuniones" Del objeto instanciado  ui de la clase UI
  // y le paso la instancia de todas las reuniones (El arreglo con todas las reuniones)
  ui.imprimirReuniones(administrarReuniones);
}

// 10.5 Declaracion funcion para reiniciar el objeto: reiniciarObjeto()
function reiniciarObjeto() {
  objetoReuniones.proyecto = "";
  objetoReuniones.estudiante = "";
  objetoReuniones.telefono = "";
  objetoReuniones.fecha = "";
  objetoReuniones.hora = "";
  objetoReuniones.detalles = "";
}
// 13.4 declaracion funcion "eliminarReunion" y definicion del
// metodo "eliminarReunion" en la clase Reuniones
function eliminarReunion(id) {
// 13.6 eliminacion de la reunion
administrarReuniones.eliminarReunion(id);
// 13.7 impresion de mensaje de notificacion de eliminacion
ui.imprimirAlerta("Reunión eliminada satisfactoriamente", "error");
// 13.8 refrescar la impresion de las reuniones sin la eliminada
ui.imprimirReuniones(administrarReuniones);
 }
