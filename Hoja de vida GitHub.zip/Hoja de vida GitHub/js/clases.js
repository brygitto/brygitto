/* Repaso clases */
/* Definicion de clase */
class Cliente {
  /* constructor */
  constructor(nombre, sueldo) {
    this.nombre = nombre;
    this.sueldo = sueldo;
  }
  /* metodos */
  mostrarInfo() {
    return `el cliente ${this.nombre} tiene un sueldo de: ${this.sueldo}`;
  }
}

/* Instancias */
const clienteBucaramanga = new Cliente("Pedro", 400);
const clienteBogota = new Cliente("Juan", 400);

/* usando los metodos */
console.log(clienteBucaramanga.mostrarInfo());
console.log(clienteBogota.mostrarInfo());

class Departamento {
  constructor(nombre, numHabitantes, extTerritorial) {
    this.nombre = nombre;
    this.numHabitantes = numHabitantes;
    this.extTerritorial = extTerritorial;
  }

  mostrarInformacion() {
    return `El Departamento de: ${this.nombre} tiene una poblancion de: ${this.numHabitantes} cuya extension terriotorial es: ${this.extTerritorial}`;
  }
}

const departamento1 = new Departamento("Santander", 900000, 70000);

console.log(departamento1.mostrarInformacion());
